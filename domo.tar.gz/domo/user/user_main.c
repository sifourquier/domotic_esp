/******************************************************************************
	* Copyright 2013-2014 Espressif Systems (Wuxi)
	*
	* FileName: user_main.c
	*
	* Description: entry file of user application
	*
	* Modification history:
	*     2014/1/1, v1.0 create this file.
	*******************************************************************************/
#include "ets_sys.h"
#include "os_type.h"
#include "osapi.h"
#include "mem.h"
#include "gpio.h"
#include "user_mqtt.h"
#include "../mqtt/include/mqtt.h"
#include "driver/adc.h"
#include "driver/timer.h"
#include "driver/spi.h"
#include "driver/i2c_master.h"
#include "user_config_mqtt.h"
#include "TLI4970.h"
#include "bme280.h"

#include "espconn.h"
#include "driver/uart.h"
#include "driver/ws2812.h"
#include "sin.h"

#define TEMP_CONFIG 5000

#define RECEIVEGPIO_ZERO_CROSS  4
#define FUNC_GPIO_ZERO_CROSS  FUNC_GPIO4
#define PERIPHS_IO_MUX_ZERO_CROSS PERIPHS_IO_MUX_GPIO4_U
#define BIT_TRIAC 15

char BIT_PWM[NB_PWM]={4,5};
//#define TIME_ANTI_REBOND 50 //ms
#define PRECISION_TIMER 99 //us a 17 on a des reset
#define TIME_SAMPLE_CURENT 500 //us si modifier modifier sin.h en consequance
#define NB_MESURE_ADC_BEFOR_SEND 2000 //1 secondes
#define FREQUANCE_RESEAUX 50
#define NB_ECHANTILLON_FILTRE ((1000000/TIME_SAMPLE_CURENT/FREQUANCE_RESEAUX))

#define USE_US_TIMER

#ifdef SEND_SWITCH_AT_START
const int PORT_QT1040[4]={PERIPHS_IO_MUX_GPIO0_U,PERIPHS_IO_MUX_U0TXD_U,PERIPHS_IO_MUX_GPIO2_U,PERIPHS_IO_MUX_U0RXD_U};
const int PORT_FUNC_QT1040[4]={FUNC_GPIO0,FUNC_GPIO1,FUNC_GPIO2,FUNC_GPIO3};
unsigned char stat_switch; 
#endif

#ifdef SLEEP
static volatile os_timer_t timer_DisconnectMQTT;
#endif

static volatile os_timer_t timer_mesure;
static volatile os_timer_t timer_time_out_connection;

bool config_ap();
void save_and_restart();

#ifdef TLI4970_ENABLE
volatile int moyen_power=0;
os_timer_t timer_send_mesures;
volatile unsigned char TLI4970_is_enable;
#endif

MQTT_Client mqttClient;
#ifdef TRIACK
volatile int puissance_triac=0;
volatile bool timer_triack_on=0;
#endif

#ifdef PWM
volatile unsigned int puissance_pwm[NB_PWM]={0};
#endif

volatile unsigned int temp_from_zero_cross;

#define MAX_SSID_LENGTH 32 //ne pas depasser 32 risque d'over flow dans le SDK
#define MAX_PASSWORD_LENGTH 64 //ne pas depasser 64 risque d'over flow dans le SDK
#define MAX_ADRESSE_LENGTH 16 //XXX.XXX.XXX.XXX
#define MAX_LENGTH_STATION_NAME 32

uint32 ssid32bit[MAX_SSID_LENGTH/4]; //focé alingement sur 4 byte
char* ssid=(char*)ssid32bit; // Wifi SSID
uint32 MYID32bit[MAX_ID_LENGTH/4];
char* MYID=(char*)MYID32bit; // Wifi MYID
uint32 password32bit[MAX_PASSWORD_LENGTH/4];
char* password=(char*)password32bit; // Wifi Password
#define NB_ADRESSE 4 //ip, masq, gateway, serveurMQTT
uint32 adresse32bit[NB_ADRESSE][MAX_ADRESSE_LENGTH/4];
char* adresse[NB_ADRESSE]={(char*)&(adresse32bit[0]),(char*)&(adresse32bit[1]),(char*)&(adresse32bit[2]),(char*)&(adresse32bit[3])};
uint32 StationName32bit[MAX_LENGTH_STATION_NAME/4];
char *StationName=(char*)StationName32bit;
char topic[MAX_TOPIC_LENGTH];

unsigned int t_sleep;


void ICACHE_FLASH_ATTR DisconnectMQTT();

short ubat;


#define TO_HEX(i) (i <= 9 ? '0' + i : 'A' - 10 + i)

#define ABS(x) x<0 ? x : -x

typedef enum 
{
	TEMPERATURE=0,
	TEMPERATURE_MIN,
	TEMPERATURE_MAX,
	CURRENT,
	POWER,
	HUMIDITY,
	LIGHT,
	VOLTAGE,
	BATTERY,
	PRESSURE,
	SPEED,
	DIRECTION,
	ICON,
	SWITCH,
}sensor_type_t;

void ICACHE_FLASH_ATTR print(char* string)
{
	uart0_sendStr(string);
	mqtt_print(&mqttClient,string);
}

void print_debug(char* string)
{
	#ifdef DEBUG_PRINT
	print(string);
	#endif
}

//paquet = {S,type,id,id,val,val,val,val)
//buffer = buffer de 8 byte
void ICACHE_FLASH_ATTR send_paquet_sensor(unsigned char* topic,sensor_type_t type, int val, int retain)
{
	int l;
	unsigned char buffer[8+MAX_LENGTH_STATION_NAME];
	if(StationName[0])
	{
		buffer[0]='S';
		buffer[1]=type;
		for(l=0;l<4;l++)
		{
			buffer[2+l]=val>>((3-l)*8);
		}
		l=0;
		while(StationName[l]&&l<MAX_LENGTH_STATION_NAME)
		{
			buffer[6+l]=StationName[l];
			l++;
		}
		buffer[6+l]=0;
		
		MQTT_Publish(&mqttClient, topic, (char*) buffer, 7+l, 0, retain);
	}
}

char* ICACHE_FLASH_ATTR ID(char* x) //ajoute ID aux string x
{
	static char string[100];
	char* pt_string=string;
	
	while(*x)
	{
		*pt_string=*x;
		pt_string++;
		x++;
	}
	
	x=MYID;
	while(*x)
	{
		*pt_string=*x;
		pt_string++;
		x++;
	}
	*pt_string='\0';
	return string;
}

char* ICACHE_FLASH_ATTR ad_name(char* x) //ajoute ID aux string x
{
	static char string[100];
	char* pt_string=string;
	
	while(*x)
	{
		*pt_string=*x;
		pt_string++;
		x++;
	}
	
	x=StationName;
	while(*x)
	{
		*pt_string=*x;
		pt_string++;
		x++;
	}
	*pt_string='\0';
	return string;
}

unsigned int stringToUint(char* str)
{
	int val=0;
	while(((*str)>='0') && ((*str)<='9'))
	{
		val=val*10+((*str)-'0');
		str++;
	}
	return val;
}

void ICACHE_FLASH_ATTR int_to_srthex(int val, char* str) //str=tab 10 char
{
	int l;
	
	for(l=0;l<8;l++)
	{
		char temp=(val>>(l*4))&0xF;
		temp=TO_HEX(temp);
		str[8-l]=temp;
	}
	str[0]=' ';
	for(l=0;l<7;l++)
	{
		if(str[l+1]!='0')
			break;
		str[l+1]=' ';
	}
	str[9]=0;
}


typedef enum
{
	WAIT,
	CONFIG_SSID,
	CONFIG_TOPIC,
	CONFIG_T_SLEEP,
	CONFIG_NAME,
	CONFIG_PASSWORD,
	CONFIG_ADDRESSE
} stateRxUart;

void ICACHE_FLASH_ATTR print_menu()
{
	print("\n\ns) modifie ssid\np) modifie password\na) modifie addresse\nn) modifie netmask\ng) modifie gateway\nm) modifie MQTT serveur\ni) modifie name\nx) modifie sleep time [s]\nc) Configure and save\n");
}

void ICACHE_FLASH_ATTR rx_uart0(char c)
{
	static stateRxUart state=WAIT;
	static unsigned char pointeur;
	static int num_adresse;
	static char str_number[10];
	#ifdef SLEEP
	os_timer_disarm(&timer_DisconnectMQTT);
	os_timer_setfn(&timer_DisconnectMQTT, (os_timer_func_t *)DisconnectMQTT, NULL);
	os_timer_arm(&timer_DisconnectMQTT, 3000, 0);
	#endif
	
	switch (state)
	{
		case WAIT:
			switch(c)
			{
				case 's':
				case 'S':
					state=CONFIG_SSID;
					pointeur=0;
					print("SSID=");
					break;
				case 'p':
				case 'P':
					state=CONFIG_PASSWORD;
					pointeur=0;
					print("PASSWORD=");
					break;
				case 'a':
				case 'A':
					state=CONFIG_ADDRESSE;
					pointeur=0;
					num_adresse=0; //IP
					print("empy for DHCP\nIP=");
					break;
				case 'n':
				case 'N':
					state=CONFIG_ADDRESSE;
					pointeur=0;
					num_adresse=1; //Net mask
					print("MASK=");
					break;
				case 'g':
				case 'G':
					state=CONFIG_ADDRESSE;
					pointeur=0;
					num_adresse=2; //Net mask
					print("GW=");
					break;
				case 'm':
				case 'M':
					state=CONFIG_ADDRESSE;
					pointeur=0;
					num_adresse=3; //Net mask
					print("MQTT=");
					break;
				case 'i':
				case 'I':
					state=CONFIG_NAME;
					pointeur=0;
					print("Name (no Name => MQTT disable)=");
					break;
				case 'c':
				case 'C':
					save_and_restart();
					break;
				default:
					print_menu();
					break;
				case 't':
				case 'T':
					state=CONFIG_TOPIC;
					pointeur=0;
					break;
#ifdef SLEEP
				case 'x':
				case 'X':
					state=CONFIG_T_SLEEP;
					pointeur=0;
					print("Time=");
					break;
#endif
					
			}
			break;
#ifdef SLEEP
				case CONFIG_T_SLEEP:
					switch(c)
					{
						case '\n':
						case '\r':
							str_number[pointeur]=0;
							state=WAIT;
							t_sleep=stringToUint(str_number);
							if(t_sleep>T_LONG_SLEEP)
								t_sleep=T_LONG_SLEEP;
							print("\n0x");
							int_to_srthex(t_sleep,str_number);
							print(str_number);
							break;
							
						default:
							str_number[pointeur]=c;
							if(pointeur<sizeof(str_number)-1)
								pointeur++;
							else
								print("Number to high");
							break;
					}
					break;
#endif
			
				case CONFIG_TOPIC:
					switch(c)
					{
						case '\n':
						case '\r':
							topic[pointeur]=0;
							state=WAIT;
							//system_rtc_mem_write(64,topic,MAX_TOPIC_LENGTH);
							MQTT_Subscribe(&mqttClient, topic, 0);
#ifdef SLEEP
							os_timer_arm(&timer_DisconnectMQTT, 800, 0);
#endif
							break;
							
						default:
							topic[pointeur]=c;
							if(pointeur<MAX_TOPIC_LENGTH-1)
								pointeur++;
							else
								print("Topic to long");
							break;
					}
					break;
					
						case CONFIG_SSID:
							switch(c)
							{
								case '\n':
								case '\r':
									ssid[pointeur]=0;
									state=WAIT;
									print_menu();
									break;
									
								default:
									ssid[pointeur]=c;
									if(pointeur<MAX_SSID_LENGTH-1)
										pointeur++;
									else
										print("SSID to long");
									break;
							}
							break;
							
								case CONFIG_NAME:
									switch(c)
									{
										case '\n':
										case '\r':
											StationName[pointeur]=0;
											state=WAIT;
											print_menu();
											break;
											
										default:
											StationName[pointeur]=c;
											if(pointeur<MAX_LENGTH_STATION_NAME -1)
												pointeur++;
											else
												print("Name to long");
											break;
									}
									break;
									
										case CONFIG_PASSWORD:
											switch(c)
											{
												case '\n':
												case '\r':
													password[pointeur]=0;
													state=WAIT;
													print_menu();
													break;
													
												default:
													password[pointeur]=c;
													if(pointeur<MAX_PASSWORD_LENGTH-1)
														pointeur++;
													else
														print("Password to long");
													break;
											}
											break;
											
												case CONFIG_ADDRESSE:
													switch(c)
													{
														case '\n':
														case '\r':
															adresse[num_adresse][pointeur]=0;
															state=WAIT;
															print_menu();
															break;
															
														default:
															adresse[num_adresse][pointeur]=c;
															if(pointeur<MAX_PASSWORD_LENGTH-1)
																pointeur++;
															else
																print("Adresse to long");
															break;
													}
													break;
	}
}

void ICACHE_FLASH_ATTR print_config()
{
	print_debug("\nSSID=");
	print_debug(ssid);
	print_debug("\npassword=");
	print_debug(password);
	print_debug("\naddresse=");
	print_debug(adresse[0]);
	print_debug("\nMask=");
	print_debug(adresse[1]);
	print_debug("\nGW=");
	print_debug(adresse[2]);
	print_debug("\nMQTT=");
	print_debug(adresse[3]);
	print_debug("\nNAME=");
	print_debug(StationName);
	print_debug("\nID=");
	print_debug(MYID);
	print_debug("\n");
	
}

void save_and_restart()
{
	print_config();
	
	ETS_INTR_LOCK(); //desactivé tout les interruption quand on fait une comunication sur le SPI
	spi_flash_erase_sector(ADRESSE_CONFIG_IN_FLASH>>12);
	spi_flash_write(ADRESSE_CONFIG_IN_FLASH,ssid32bit,MAX_SSID_LENGTH);
	spi_flash_write(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH,password32bit,MAX_PASSWORD_LENGTH);
	spi_flash_write(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH+MAX_PASSWORD_LENGTH,(uint32*)adresse32bit,MAX_ADRESSE_LENGTH*NB_ADRESSE);
	spi_flash_write(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH+MAX_PASSWORD_LENGTH+MAX_ADRESSE_LENGTH*NB_ADRESSE,StationName32bit,MAX_ID_LENGTH);
	spi_flash_write(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH+MAX_PASSWORD_LENGTH+MAX_ADRESSE_LENGTH*NB_ADRESSE+MAX_LENGTH_STATION_NAME,&t_sleep,sizeof(t_sleep));
	
	print_debug("\n\nCONFIG WRITED\n\n");
	
	ETS_INTR_UNLOCK();
	system_restart();
	
}

bool ICACHE_FLASH_ATTR config_ap()
{
	//wifi_station_disconnect();
	struct station_config stationConf; // Station conf struct
	
	print_config();
	
	if(adresse[0][0]) //si adresse non null (pas de DHCP)
	{
		struct ip_info info;
		wifi_station_dhcpc_stop();
		info.ip.addr = ipaddr_addr(adresse[0]);
		info.netmask.addr = ipaddr_addr(adresse[1]);
		info.gw.addr = ipaddr_addr(adresse[2]);
		wifi_set_ip_info(STATION_IF, &info);
		
	}
	else//DHCP
	{
		wifi_set_ip_info(STATION_IF, NULL);
		wifi_station_dhcpc_start();
	}
	
	ssid[MAX_SSID_LENGTH-1]=0; //evite les risque d'overflow
	password[MAX_PASSWORD_LENGTH-1]=0;
		
	wifi_set_opmode(0x1); // Set station mode
	os_memcpy(&stationConf.ssid, (uint32 *)ssid, MAX_SSID_LENGTH); // Set settings
	os_memcpy(&stationConf.password, (uint32 *)password, MAX_PASSWORD_LENGTH); // Set settings 
	stationConf.bssid_set = 0;
	wifi_station_set_config(&stationConf); // Set wifi conf
	return 1;
}

#ifdef TLI4970_ENABLE
void timerMesureSampleAdc(void)//ne pas apeler de fonction en flash dans une fonction du timer
{	
	if(StationName[0] && mqttIsConected())
	{
		static unsigned int num_mesure=0;
		static long int sum=0;
		
		//static int tab_filtre[NB_ECHANTILLON_FILTRE];
		//adc_value += system_adc_read();
		//DEBUG("send1\n\r");
		
		int val=0;
		
		//bug apres x seconde valeur enorme
		if(TLI4970_is_enable)
		{
			if(TLI4970_is_enable==2)//si il est alumer depui un moment
			{
				val=TLI4970_get_curent();
			}
			else//si on vien de l'alumer
			{
				TLI4970_is_enable=2;
			}
		}
		else
		{
			TLI4970_disable();
		}
		temp_from_zero_cross++;
		if(temp_from_zero_cross>=40)
			temp_from_zero_cross=0;
		sum+=val*tab_sin[temp_from_zero_cross];
		num_mesure++;
		
		if(num_mesure>=NB_MESURE_ADC_BEFOR_SEND)
		{
			moyen_power=sum/NB_MESURE_ADC_BEFOR_SEND;
			num_mesure=0;
			sum=0;
		}
	}
}
#endif

#ifdef PWM
void timerPwm1()
{
	static unsigned char on=0;
	if(on && puissance_pwm[0])
	{
		on=0;
		GPIO_REG_WRITE(GPIO_OUT_W1TC_ADDRESS, 1<<BIT_PWM[0]);
		timer_change_callback((100-puissance_pwm[0])*PWM_SCALL,(t_call_back)timerPwm1);
	}
	else
	{
		on=1;
		GPIO_REG_WRITE(GPIO_OUT_W1TS_ADDRESS, 1<<BIT_PWM[0]);
		timer_change_callback(puissance_pwm[0]*PWM_SCALL,(t_call_back)timerPwm1);
	}
}
#endif

#ifdef TRIACK
void timerEnableTriack()
{
	timer_change_callback(10000-100,(t_call_back)timerEnableTriack);
	GPIO_REG_WRITE(GPIO_OUT_W1TS_ADDRESS, 1<<BIT_TRIAC);
	//GPIO_OUTPUT_SET(BIT_TRIAC,1);
	/*os_delay_us(100);
	GPIO_OUTPUT_SET(BIT_TRIAC,0);*/
}

void ZeroCross()//après iRQ + après 10ms
{
	#ifdef TLI4970_ENABLE

	if(puissance_triac>0)
	{
		if(!TLI4970_is_enable)
		{
			TLI4970_enable();
			TLI4970_is_enable=1;
		}
	}
	else
	{
		TLI4970_is_enable=0;
	}
	#endif
	
	if(puissance_triac==PUISSANCE_MAX)
	{
		
		if(timer_triack_on)
		{
			timer_remove_callback((t_call_back)timerEnableTriack);
			timer_triack_on=0;
		}
		//GPIO_OUTPUT_SET(BIT_TRIAC,1); //toujour a 1
		GPIO_REG_WRITE(GPIO_OUT_W1TS_ADDRESS, 1<<BIT_TRIAC);

	}
	else if(puissance_triac>0)
	{
		//GPIO_OUTPUT_SET(BIT_TRIAC,0);
		GPIO_REG_WRITE(GPIO_OUT_W1TC_ADDRESS, 1<<BIT_TRIAC);

		if(timer_triack_on)
		{
			timer_change_callback(10000-puissance_triac,(t_call_back)timerEnableTriack);
		}
		else
		{
			timer_add_callback(10000-puissance_triac,(t_call_back)timerEnableTriack);
			timer_triack_on=1;
		}
	}
	else
	{
		if(timer_triack_on)
		{
			timer_remove_callback((t_call_back)timerEnableTriack);
			timer_triack_on=0;
		}
		GPIO_REG_WRITE(GPIO_OUT_W1TC_ADDRESS, 1<<BIT_TRIAC);
		
	}
}

void timerZeroCross() //reactivez l'ibnteruption et simule le 2eme zero cross
{
	uint32 gpio_status = GPIO_REG_READ(GPIO_STATUS_ADDRESS);
	//clear interrupt status
	GPIO_REG_WRITE(GPIO_STATUS_W1TC_ADDRESS, gpio_status);
	
	gpio_pin_intr_state_set(GPIO_ID_PIN(RECEIVEGPIO_ZERO_CROSS), GPIO_PIN_INTR_NEGEDGE); // enable IRQ	
	
	timer_remove_callback((t_call_back)timerZeroCross);
	ETS_GPIO_INTR_ENABLE();
	
	ZeroCross();
}

void ZeroCrossIRQ()
{
	timer_tim1_intr_handler(); //resicronise le timer
	ETS_GPIO_INTR_DISABLE();
	temp_from_zero_cross=0;
	//os_delay_us(1);*/
	uint32 gpio_status;
	gpio_pin_intr_state_set(GPIO_ID_PIN(RECEIVEGPIO_ZERO_CROSS), GPIO_PIN_INTR_DISABLE); // disable IRQ*/
	gpio_status = GPIO_REG_READ(GPIO_STATUS_ADDRESS);
	//clear interrupt status
	GPIO_REG_WRITE(GPIO_STATUS_W1TC_ADDRESS, gpio_status);
	
	timer_add_callback(10000+1,(t_call_back)timerZeroCross);
	
	ZeroCross();
}


void ICACHE_FLASH_ATTR init_IRQ_zero_cross()
{
	ETS_GPIO_INTR_DISABLE();	
	ETS_GPIO_INTR_ATTACH(ZeroCrossIRQ, RECEIVEGPIO_ZERO_CROSS);
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_ZERO_CROSS, FUNC_GPIO_ZERO_CROSS);
	//gpio_output_set(0, 0, 0, BIT(RECEIVEGPIO_ZERO_CROSS));
	GPIO_DIS_OUTPUT(RECEIVEGPIO_ZERO_CROSS);
	//PIN_PULLDWN_DIS(PERIPHS_IO_MUX_ZERO_CROSS);
	PIN_PULLUP_EN(PERIPHS_IO_MUX_ZERO_CROSS);
	GPIO_REG_WRITE(GPIO_STATUS_W1TC_ADDRESS, BIT(RECEIVEGPIO_ZERO_CROSS));
	gpio_pin_intr_state_set(GPIO_ID_PIN(RECEIVEGPIO_ZERO_CROSS), GPIO_PIN_INTR_NEGEDGE); // Interr	

	ETS_GPIO_INTR_ENABLE();
}
#endif

#ifdef BME280

void timer_mesure_handler(void *arg)
{
	unsigned int pressure;
	int temperature;
	int humidity;
	
 	bme280_read_pressure_temperature_humidity(&pressure,&temperature, &humidity);
	bme280_set_power_mode(BME280_SLEEP_MODE);
	
	send_paquet_sensor(ID("/sensors/temperatures/"),TEMPERATURE,temperature,1);
	send_paquet_sensor(ID("/sensors/humiditys/"),HUMIDITY,humidity/10,1);
	send_paquet_sensor(ID("/sensors/pressures/"),PRESSURE,pressure,1);
	send_paquet_sensor(ID("/sensors/batterys/"),BATTERY,ubat,1);
}
#endif

#ifdef SLEEP
void ICACHE_FLASH_ATTR go_sleep()
{
	print_debug("sleep\n");
	//uart0_sendStr("S\n");
#ifdef METEO
	gpio_output_set(BIT5, 0, BIT5, 0); //on est plus reveillé
#endif
	system_deep_sleep(t_sleep*1000*1000);
}

void ICACHE_FLASH_ATTR diconnectedCB()
{
	//uart0_sendStr("diconnectedCB\n");
}

void ICACHE_FLASH_ATTR DisconnectMQTT()
{
	MQTT_OnDisconnected(&mqttClient,diconnectedCB);
	//uart0_sendStr("diconnect\n");
	MQTT_Disconnect(&mqttClient); ///non testé sans ecrant
	if(topic[0]!=0) 
	{
		uart0_sendStr("\1stE");//le module passe en veille
	}
	uart0_sendStr("DisconnectMQTT");
	os_timer_disarm(&timer_DisconnectMQTT);
	os_timer_setfn(&timer_DisconnectMQTT, (os_timer_func_t *)go_sleep, NULL);
	os_timer_arm(&timer_DisconnectMQTT, 20, 0); //temp pour envoyer deconnection
}
#endif



void ICACHE_FLASH_ATTR connectedCB(void *arg)
{
	//uart0_sendStr(topic);
	//if(topic[0])
		//MQTT_Subscribe(&mqttClient, topic, 0);
	print_debug("connectedCB\n");
	
	#ifdef TLI4970_ENABLE
	timer_add_callback(TIME_SAMPLE_CURENT,(t_call_back)timerMesureSampleAdc);
	#endif	
	
	#ifdef PWM
	timer_add_callback(100*PWM_SCALL,(t_call_back)timerPwm1);
	#endif
	
	#ifdef SLEEP
	/*os_timer_disarm(&timer_mesure);
*	os_timer_setfn(&timer_mesure, (os_timer_func_t *)timer_mesure_handler, NULL);
*	os_timer_arm(&timer_mesure, 20, 0);*/

	os_timer_disarm(&timer_DisconnectMQTT);
	os_timer_setfn(&timer_DisconnectMQTT, (os_timer_func_t *)DisconnectMQTT, NULL);
	if(topic[0]==0)
		os_timer_arm(&timer_DisconnectMQTT, 200, 0);
	else
		os_timer_arm(&timer_DisconnectMQTT, 800, 0);
	#endif
	
#ifdef SEND_SWITCH_AT_START
	i2c_master_start();
	i2c_master_writeByte(PCF8885_ADRESSE|I2C_READ);
	i2c_master_getAck();
	stat_switch=i2c_master_readByte();
	i2c_master_send_nack();
	i2c_master_stop();
	
	int l;
	for(l=0;l<sizeof(stat_switch)*8;l++)
	{
		if((stat_switch>>l)&0x01)
			send_paquet_sensor(ID("sensors/switch/"),SWITCH,l+1,0);
	}
#endif
}

#ifdef TLI4970_ENABLE
void ICACHE_FLASH_ATTR time_send_mesures(void *arg)
{
	send_paquet_sensor(ID("sensors/powers/"),POWER,moyen_power,0);
}
#endif

void mqttDataCb(uint32_t *args, const char* topic, uint32_t topic_len, const char *data, uint32_t data_len)
{
	int l;
	#ifdef SLEEP //si on recoi des donné on reset le timer qui passe en sleep
	os_timer_disarm(&timer_DisconnectMQTT);
	os_timer_setfn(&timer_DisconnectMQTT, (os_timer_func_t *)DisconnectMQTT, NULL);
	os_timer_arm(&timer_DisconnectMQTT, 200, 0);
	#endif
	
	/*char *topicBuf = (char*)os_zalloc(topic_len+1),
			*dataBuf = (char*)os_zalloc(data_len+1);

	DEBUG("MQTT: mqttDataCb\r\n");

	MQTT_Client* client = (MQTT_Client*)args;

	os_memcpy(topicBuf, topic, topic_len);
	topicBuf[topic_len] = 0;

	os_memcpy(dataBuf, data, data_len);
	dataBuf[data_len] = 0;*/

	/*DEBUG("Receive topic: ");
	DEBUG(topicBuf);
	DEBUG(", data: ");
	DEBUG(dataBuf);
	DEBUG("\n");*/
	
	//DEBUG(data);
	
#ifdef TRIACK
	uart0_sendStr("s");

	//if(topicCmp(topicLight,topicBuf))
	{
		if(data[0]=='S')
		{
			if(data[1]>0)
			{
				if(data[1]==100)
					puissance_triac=PUISSANCE_MAX;
				else
					puissance_triac=(data[1]*data[1]*10/11)+TRIAC_MIN;
			}
			else
				puissance_triac=0;

		}
		if(data[0]=='T')
		{
			if(puissance_triac)
				puissance_triac=0;
			else
				puissance_triac=PUISSANCE_MAX;
		}
	}
#endif
#ifdef PWM
for(l=0;l<NB_PWM && (l+1)<data_len;l++)
{
		if(data[0]=='S')
		{
			puissance_pwm[l]=data[1+l]*PWM_SCALL;
		}
		if(data[0]=='T')
		{
			if(puissance_pwm)
				puissance_pwm[l]=0;
			else
				puissance_pwm[l]=100*PWM_SCALL;
		}
}
#endif

#ifdef SEND_MQTT_ON_UART
	/*char *dataBuf = (char*)os_zalloc(data_len+1);
	os_memcpy(dataBuf, data, data_len);
	dataBuf[data_len] = 0;*/
	uart0_sendStr("\1stS");
	uart0_write_char(data_len);
	uart0_write_char(data_len>>8);
	uart0_tx_buffer((uint8*)data,data_len);
	//os_free(dataBuf);
#endif
	

}

void ICACHE_FLASH_ATTR user_init(void)
{

	volatile int l;
	
	system_deep_sleep_set_option(2);
	
#ifdef METEO
	gpio_output_set(0, BIT5, BIT5, 0); //dire qu'on est reveiller
#endif
	
#ifdef SEND_SWITCH_AT_START
	//stat_switch=1;
	/*for(l=0;l<4;l++)
	{
		PIN_FUNC_SELECT(PORT_QT1040[l], PORT_FUNC_QT1040[l]);
		GPIO_DIS_OUTPUT(PORT_QT1040[l]);
		PIN_PULLUP_EN(PORT_QT1040[l]);
	}*/
#endif
	
	uart_init(BIT_RATE_115200,BIT_RATE_115200);
		
	//os_install_putc1(NULL);
	
	/*char string[15]="\nubat";
	int_to_srthex(ubat,string+5);
	print(string);*/
	/*char string2[15]="\nstat";
	int_to_srthex(wifi_station_get_connect_status(),string2);
	print(string2);*/

#ifdef ON_BATTERY
	ubat=( (int)system_adc_read()<<6)/21;
	if(ubat<1200) //si vbat trop faible
	{
		print_debug("lowbat\n");
		system_deep_sleep_set_option(4);
		system_deep_sleep(T_LONG_SLEEP*1000*1000);
 	}
#endif
	
	
	#if defined(BME280) || defined(TLI4970_ENABLE)
	spi_init(HSPI,9); //configure SPI Fcpu /4/(x-1)
	#endif
	#ifdef BME280
	SPI_routine();
	bme280_set_power_mode(BME280_NORMAL_MODE);
	//os_delay_us(10000);
	//bme280_read_pressure_temperature_humidity(&old_pressure,&old_temperature, &old_humidity);//recupere les ancienne valeur
	bme280_init_user();
	#ifdef SLEEP
	os_timer_disarm(&timer_mesure);
	os_timer_setfn(&timer_mesure, (os_timer_func_t *)timer_mesure_handler, NULL);
	os_timer_arm(&timer_mesure, 100, 0);
	#endif
	#endif
	
	ETS_UART_INTR_DISABLE(); //desactive IRQ uart durant l'ecriture (recomandé)
	spi_flash_read(ADRESSE_CONFIG_IN_FLASH,ssid32bit,MAX_SSID_LENGTH);
	spi_flash_read(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH,password32bit,MAX_PASSWORD_LENGTH);
	spi_flash_read(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH+MAX_PASSWORD_LENGTH,(uint32*)adresse32bit,MAX_ADRESSE_LENGTH*NB_ADRESSE);
	spi_flash_read(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH+MAX_PASSWORD_LENGTH+MAX_ADRESSE_LENGTH*NB_ADRESSE,StationName32bit,MAX_LENGTH_STATION_NAME);
	spi_flash_read(ADRESSE_CONFIG_IN_FLASH+MAX_SSID_LENGTH+MAX_PASSWORD_LENGTH+MAX_ADRESSE_LENGTH*NB_ADRESSE+MAX_LENGTH_STATION_NAME,&t_sleep,sizeof(t_sleep));
	StationName[MAX_LENGTH_STATION_NAME-1]='\0';
	int_to_srthex(system_get_chip_id(),MYID);
	
	for(l=0;l<NB_ADRESSE;l++)
		adresse[l][MAX_ADRESSE_LENGTH-1]=0;
	password[MAX_PASSWORD_LENGTH-1]=0;
	ssid[MAX_SSID_LENGTH-1]=0;
	
	//system_rtc_mem_read(64,topic,MAX_TOPIC_LENGTH);
	//print(topic);
	
	#ifdef PWM
	for(l=0;l<NB_PWM;l++)
	{
		GPIO_OUTPUT_SET(BIT_PWM[l],0);
	}
	
	#endif
	print_debug("start\n");
	
	config_ap();
	ETS_UART_INTR_ENABLE(); //reactiver IRQ
	
	if(StationName[0])
		mqttInit(&mqttClient,adresse[3],(t_call_back_connected)connectedCB);
	
	#ifdef TLI4970_ENABLE
	os_timer_disarm(&timer_send_mesures); // dis_arm the timer
	os_timer_setfn(&timer_send_mesures, (os_timer_func_t *)time_send_mesures, NULL); // set the timer function, dot get os_timer_func_t to force function convert
	os_timer_arm(&timer_send_mesures, 2000, 1);//tout les 2seconde
	#endif
	
	#if defined(TRIACK) || defined(TLI4970_ENABLE) || defined(PWM)
	timer_init(PRECISION_TIMER);
	#else
	wifi_set_sleep_type(LIGHT_SLEEP_T ); //impossible de comuniquer en uart durant les phase de sleep et le timer ne semble plus fonctioner
	#endif

	#ifdef TLI4970_ENABLE
		TLI4970_init();
		TLI4970_enable();
	#endif
		
	
#ifdef SLEEP
	os_timer_disarm(&timer_time_out_connection); // dis_arm the timer
	os_timer_setfn(&timer_time_out_connection, (os_timer_func_t *)DisconnectMQTT, NULL); // set the timer function, dot get os_timer_func_t to force function convert
	os_timer_arm(&timer_time_out_connection, TIMOUT_CONNECTION, 1);
#endif
	
	#ifdef SEND_SWITCH_AT_START
	/*for(l=0;l<4;l++)
	{
		if(!GPIO_INPUT_GET(PORT_QT1040[l]))
			stat_switch|=1<<(l+1);
	}*/
#endif 

	#ifdef TRIACK
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTDO_U,FUNC_GPIO15); //triac
	gpio_output_set(0,BIT(BIT_TRIAC), BIT(BIT_TRIAC), 0);
	GPIO_OUTPUT_SET(BIT_TRIAC,0);
	print_debug("init_IRQ_zero_cross\n");
	init_IRQ_zero_cross();
	#endif
	
	uart0_sendStr("\1stB");//le module a demaré
	
}

void user_rf_pre_init(void)
{
	system_update_cpu_freq(160); //ne semble pas changer la consomation
	//a verifier si modifi le CLK du SPI
}


user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 8;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;

        default:
            rf_cal_sec = 0;
            break;
    }
    return rf_cal_sec;
}
