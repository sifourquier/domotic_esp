int TLI4970_get_curent();
void TLI4970_init();
void TLI4970_enable();
void TLI4970_disable();