//void ICACHE_FLASH_ATTR read_adcs(uint16 *ptr, uint16 len);
uint16 adc_read(void);